#' Alternative name for \code{sim.coor.song}
#' 
#' @description \code{sim_coor_sing} alternative name for \code{sim.coor.song}. \code{sim.coor.song} will be deprecated in 
#' future versions.
#' 
"sim_coor_sing" 
