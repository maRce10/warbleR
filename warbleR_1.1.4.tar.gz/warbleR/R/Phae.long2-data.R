#' Acoustic recording #2 of \emph{Phaethornis longirostris}
#' 
#'   Acoustic recording #2 of \emph{Phaethornis longirostris}  (Long-billed Hermit).
#' 
#' @format One .wav file: \describe{
#'   
#'   \item{Phae.long2}{\emph{Phaethornis longirostris} #2 recording}
#'   
#'   }
#' 
#' @usage data(Phae.long2) 
#' 
#' @source \url{http://www.xeno-canto.org/contributor/EMCWQLLKEW}
"Phae.long2" 
