#' Acoustic recording #3 of \emph{Phaethornis longirostris}
#' 
#'   Acoustic recording #3 of \emph{Phaethornis longirostris} (Long-billed Hermit).
#' 
#' @format One .wav file: \describe{
#'   
#'   \item{Phae.long3}{\emph{Phaethornis longirostris} #3 recording}
#'   
#'   }
#'  
#' @usage data(Phae.long3)
#' 
#' @source \url{http://www.xeno-canto.org/contributor/EMCWQLLKEW}       
"Phae.long3" 
