#' Selections files from Raven and Syrinx.
#' 
#' @format \describe{
#'   
#'   \item{selection.files}{Selections from the commercial software `Raven` and `Syrinx`}
#'   
#'   }
#'   
#' @usage data(selection.files)
#' 
"selection.files" 
